# remark-preset-lint-node
remark preset to configure remark-lint with settings for nodejs/node
